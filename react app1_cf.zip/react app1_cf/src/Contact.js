import React from "react";

export default function Contact(){
    return (
        <h1>contact us page</h1>
    );
}