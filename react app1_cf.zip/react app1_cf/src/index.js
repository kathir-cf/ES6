import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import AppComp from './App.js';
ReactDOM.render(<AppComp />,  document.getElementById('root1'));

//ReactDOM.render(what,where);
//ReactDOM can spk with VDOM 
