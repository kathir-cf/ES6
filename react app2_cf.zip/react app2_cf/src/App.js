import logo from './logo.svg';
import './App.css';
import React from 'react';
import Nested from './Nested.js';
import CounterComp from './CounterComp';
//class component
//functional components / arrow function
//treat it as root component
//info can be shared from a parent to child thru props
//child are designed mostly for presentational purpose till react 16
//mostly child comp are created using functional comp till react 16
//parent component are to maintain the state and child are to handle presentation
//props: userdefined attributes of JSX elements, 
class AppComp extends React.Component{

  state={
    age:98
  }
  render(){
  //  const age=90;//local to functions
    //++age;//Assignment to constant variable. not possible
    return(
      
    <div>
      
     <h1>hi hello!!!</h1>
     <p> welcome</p>
     <p>hi user</p>
     <CounterComp/>
     <Nested age={this.state.age} />
     </div>
     );
  }
}
/*
//functional component
function App(){
  return <div><h1>hi hello</h1><p> welcome</p>
  <p>hi user</p></div>
}


const AppComp=()=>{
  return (
  <div>
    <h1>hi hello - parent  comp</h1>
    <p> welcome</p>
    <p>hi user</p>
    <Nested/>
  </div>);
}
*/


export default AppComp;
//export default compname;