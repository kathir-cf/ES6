import React from "react";



export default class CounterComp extends React.Component{

    // state={
    //     counter:0
    // }
    constructor(){
        super();
        this.state={
            counter:0
        }
    }

    buttonClick=(event)=>{
        //console.log(event);
        //this.state.counter=900;//dont assign value directly
        this.setState({counter:89});//will invoke render fn
    }

    render(){
//dont assign value of state or dont call setstate in render
        return <div><h1>count is {this.state.counter}</h1>
        <button onClick={this.buttonClick}><h1>+</h1></button>
        </div>
    }
}