import React from "react";
import Contact  from "./Contact";
export default function Nested(props){
    //props.age=78;//Uncaught TypeError: Cannot assign to read only property 'age'
    //props are immutable
    return (
        <div>
         age is    {props.age}
        <h1>nested element - child</h1>
        <Contact/>
        </div>
    );
}